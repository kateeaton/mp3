import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Vector;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        //parse the training data and store in arrays yesData and noData
        Parser parser = new Parser();
        ArrayList<ArrayList<String>> puzzle = parser.Parse("no_train.txt");
        Character[][][] noData = parser.toMatrix(puzzle);
        ArrayList<ArrayList<String>> puzzle0 = parser.Parse("yes_train.txt");
        Character[][][] yesData = parser.toMatrix(puzzle0);

        //train the AI with the training data for no and implement laplace smoothing
        Train trainer = new Train();
        Double[][] noTrainingOutput;
        noTrainingOutput = trainer.trainInput(noData);
        Double k = 3.1;
        //System.out.println();
        //System.out.println(k);
        noTrainingOutput = trainer.laplaceSmoothing(noTrainingOutput, k, 2, noData.length);

        //train the AI with the training data for yes and implement laplace smoothing
        Train yesTrainer = new Train();
        Double[][] yesTrainingOutput;
        yesTrainingOutput = yesTrainer.trainInput(yesData);
        yesTrainingOutput = yesTrainer.laplaceSmoothing(yesTrainingOutput, k, 2, yesData.length);

        //Parse the no and yes tests
        ArrayList<ArrayList<String>> noTest = parser.Parse("no_test.txt");
        Character[][][] noTestData = parser.toMatrix(noTest);

        ArrayList<ArrayList<String>> yesTest = parser.Parse("yes_test.txt");
        Character[][][] yesTestData = parser.toMatrix(yesTest);

        //Test the no and yes tests, print the result to the console
        double probNo = ((double)noData.length / ((double)noData.length + (double)yesData.length));
        double probYes = 1 - probNo;
        Double percent = trainer.test(noTrainingOutput, yesTrainingOutput, noTestData, probNo, probYes);
        Double percent2 = yesTrainer.test(noTrainingOutput, yesTrainingOutput, yesTestData, probNo, probYes);
        //System.out.println(percent);
        //System.out.println(1-percent2);

        //Part1
        System.out.println("Starting Part1");
        Train1 digitTrainer = new Train1();
        Parser parse1 = new Parser();

        //Parse all training data
        ArrayList<ArrayList<String>> unsorted = parse1.parseDigits("train.txt");
        Character[][][] images = parse1.toMatrix(unsorted);
        int[] labels = parse1.digitLabelParse("trainl.txt");

        //train digits
        int[] digitTotals = digitTrainer.getDigitTotals(labels);
        Double[][][] TrainedData = digitTrainer.digitalTrain(images, labels);
        TrainedData = digitTrainer.laplaceSmoothing(TrainedData, .1, 2, digitTotals);
        Double[] digitProbabilities = digitTrainer.normalizeDigitTotals(digitTotals, labels);

        //Parse test digits
        ArrayList<ArrayList<String>> testparsing = parser.parseDigits("testimages.txt");
        Character[][][] tests = parser.toMatrix(testparsing);
        int[] testlabels = parser.digitLabelParse("testlabels.txt");

        //test testing digits against trained digits
        int[] guesses = digitTrainer.guess(TrainedData, tests, digitProbabilities);

        int[] testDigitTotals = digitTrainer.getDigitTotals(testlabels);
        Double[][] conMatrix = digitTrainer.generateConfusionMatrix(guesses, testlabels, testDigitTotals);

        //print results
        for(int i = 0; i < 10; i ++){
            System.out.print(i + ": ");
            for(int j = 0; j < 10; j++){
                System.out.print(conMatrix[i][j] + " ");
            }
            System.out.println();
        }

    }

}
